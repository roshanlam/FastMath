from stats import *

# This file is just to test the library functions

print(stand_dev([1, 2, 3]))
