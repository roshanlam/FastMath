# FastMath

The best math libary for python

## Usage

To add numbers do:
`add(1, 2)`

This is the same as 1 + 2

To subtract do:
`sub(2, 3)`

This is the same as 2 - 3

To multiply do:
`mul(2, 2)`

This is the same as 2 * 2

To divide do:
`div(4, 2)`

This is the same as 4 / 2

To caculate the area of a circle do:

`circle_area(5)`

This is the same as 5^2 * 3.14

To use the quadratic formula do:

`qudratic(6, 17, 12)`

This is the same as (-17 (+ or -) sqrt(17^2 - 4 * 6 * 12)) / 2 * 6


