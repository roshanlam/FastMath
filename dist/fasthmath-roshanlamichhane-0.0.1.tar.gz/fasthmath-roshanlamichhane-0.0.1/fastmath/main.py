from .lib import *
# importing complex math formulas
# basic formulas will be in the main.py file

def add(num1, num2):
    return num1 + num2 

def sub(num1, num2):
    return num1 - num2

def mul(num1, num2):
    return num1 * num2

def div(num1, num2):
    return num1 / num2

def circle_area(num1):
                # radius
    return 3.14 * pow(num1, 2)


